// server.js - serverul Express pentru API-ul IoT
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const { Parser } = require("json2csv");

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Baza de date SQLite (fișier local)
const db = new sqlite3.Database(path.join(__dirname, "../data/database.db"), (err) => {
  if (err) {
    console.error("Eroare la deschiderea bazei de date:", err.message);
  } else {
    console.log("Baza de date conectată.");

    // Creează tabelul dacă nu există
    db.run(`CREATE TABLE IF NOT EXISTS measurements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      temperature REAL,
      humidity REAL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
  }
});

// Ruta POST: primește date de la senzor
app.post("/api/data", (req, res) => {
  const { temperature, humidity } = req.body;
  if (typeof temperature !== "number" || typeof humidity !== "number") {
    return res.status(400).json({ error: "Date invalide" });
  }

  const stmt = db.prepare("INSERT INTO measurements (temperature, humidity) VALUES (?, ?)");
  stmt.run(temperature, humidity, function (err) {
    if (err) {
      console.error("Eroare la inserare:", err.message);
      return res.status(500).json({ error: "Inserare eșuată" });
    }
    res.json({ success: true, id: this.lastID });
  });
});

// Ruta GET: returnează ultimele N măsurători (ex: 20)
app.get("/api/history", (req, res) => {
  db.all("SELECT * FROM measurements ORDER BY timestamp DESC LIMIT 20", [], (err, rows) => {
    if (err) {
      console.error("Eroare la interogare:", err.message);
      return res.status(500).json({ error: "Eroare la citire" });
    }
    res.json(rows);
  });
});

// Ruta GET: ultima măsurătoare (pentru afișare live)
app.get("/api/latest", (req, res) => {
  db.get("SELECT * FROM measurements ORDER BY timestamp DESC LIMIT 1", [], (err, row) => {
    if (err) {
      console.error("Eroare la citire:", err.message);
      return res.status(500).json({ error: "Eroare la citire" });
    }
    res.json(row);
  });
});

// Pornire server
app.listen(port, () => {
  console.log(`Serverul rulează la http://localhost:${port}`);
});

app.delete("/api/reset", (req, res) => {
    db.run("DELETE FROM measurements", [], (err) => {
      if (err) {
        console.error("Eroare la reset DB:", err.message);
        return res.status(500).json({ message: "Eroare la resetare." });
      }
      res.json({ message: "Toate datele au fost șterse." });
    });
  }); 

// Ruta GET: exportă datele în format CSV
app.get("/api/export", (req, res) => {
    db.all("SELECT * FROM measurements ORDER BY timestamp", [], (err, rows) => {
      if (err) {
        console.error("Eroare la export:", err.message);
        return res.status(500).json({ message: "Eroare la export." });
      }
  
      const json2csv = new Parser({ fields: ["id", "temperature", "humidity", "timestamp"] });
      const csv = json2csv.parse(rows);
  
      res.header("Content-Type", "text/csv");
      res.attachment("masuratori.csv");
      res.send(csv);
    });
  });
  


  