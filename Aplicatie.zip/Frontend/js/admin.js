const token = localStorage.getItem("token");

// Protejează acțiunile dacă nu există token
if (!token) {
  window.location.href = "login.html";
}

// Ștergere date cu autorizare
document.getElementById("resetBtn").addEventListener("click", async () => {
  if (confirm("Ești sigur că vrei să ștergi toate datele?")) {
    try {
      const res = await fetch("http://localhost:3000/api/reset", {
        method: "DELETE",
        headers: {
          "Authorization": "Bearer " + token
        }
      });

      if (!res.ok) {
        throw new Error("Nu ai acces!");
      }

      const data = await res.json();
      document.getElementById("statusMsg").textContent = data.message;
    } catch (err) {
      console.error(err);
      document.getElementById("statusMsg").textContent = "Eroare la ștergere.";
    }
  }
});

// Export CSV cu autorizare
document.getElementById("exportBtn").addEventListener("click", async () => {
  try {
    const res = await fetch("http://localhost:3000/api/export", {
      method: "GET",
      headers: {
        "Authorization": "Bearer " + token
      }
    });

    if (!res.ok) {
      throw new Error("Token invalid sau expirat.");
    }

    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = url;
    link.download = "masuratori.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    document.getElementById("statusMsg").textContent = "Datele au fost exportate.";
  } catch (err) {
    console.error(err);
    document.getElementById("statusMsg").textContent = "Eroare la export.";
  }
}); 

// Buton de Logout
document.getElementById("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("token");
  window.location.href = "login.html";
});

