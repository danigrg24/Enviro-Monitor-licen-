// server.js - serverul Express pentru API-ul IoT
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const { authenticate, verifyToken } = require("./auth");
const { Parser } = require("json2csv");

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.post("/api/login", authenticate);

// Baza de date SQLite (fișier local)
const db = new sqlite3.Database(path.join(__dirname, "../data/database.db"), (err) => {
  if (err) {
    console.error("Eroare la deschiderea bazei de date:", err.message);
  } else {
    console.log("Baza de date conectată.");

    // Creează tabelul dacă nu există
    db.run(`CREATE TABLE IF NOT EXISTS measurements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      temperature REAL,
      humidity REAL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
  }
});

// Ruta POST: primește date de la senzor
app.post("/api/data", (req, res) => {
  const { temperature, humidity } = req.body;
  if (typeof temperature !== "number" || typeof humidity !== "number") {
    return res.status(400).json({ error: "Date invalide" });
  }

  const stmt = db.prepare("INSERT INTO measurements (temperature, humidity) VALUES (?, ?)");
  stmt.run(temperature, humidity, function (err) {
    if (err) {
      console.error("Eroare la inserare:", err.message);
      return res.status(500).json({ error: "Inserare eșuată" });
    }
    res.json({ success: true, id: this.lastID });
  });
});

// Ruta GET: returnează ultimele N măsurători (ex: 20)
app.get("/api/history", (req, res) => {
  db.all("SELECT * FROM measurements ORDER BY timestamp DESC LIMIT 20", [], (err, rows) => {
    if (err) {
      console.error("Eroare la interogare:", err.message);
      return res.status(500).json({ error: "Eroare la citire" });
    }
    res.json(rows);
  });
});

// Ruta GET: ultima măsurătoare (pentru afișare live)
app.get("/api/latest", (req, res) => {
  db.get("SELECT * FROM measurements ORDER BY timestamp DESC LIMIT 1", [], (err, row) => {
    if (err) {
      console.error("Eroare la citire:", err.message);
      return res.status(500).json({ error: "Eroare la citire" });
    }
    res.json(row);
  });
});

// Pornire server
app.listen(port, () => {
  console.log(`Serverul rulează la http://localhost:${port}`);
});

app.delete("/api/reset", verifyToken, (req, res) => {
    db.run("DELETE FROM measurements", [], (err) => {
      if (err) {
        console.error("Eroare la reset DB:", err.message);
        return res.status(500).json({ message: "Eroare la resetare." });
      }
      res.json({ message: "Toate datele au fost șterse." });
    });
  }); 

// Ruta GET: exportă datele în format CSV
app.get("/api/export", verifyToken, (req, res) => {
    db.all("SELECT * FROM measurements ORDER BY timestamp", [], (err, rows) => {
      if (err) {
        console.error("Eroare la export:", err.message);
        return res.status(500).json({ message: "Eroare la export." });
      }
  
      const json2csv = new Parser({ fields: ["id", "temperature", "humidity", "timestamp"] });
      const csv = json2csv.parse(rows);
  
      res.header("Content-Type", "text/csv");
      res.attachment("masuratori.csv");
      res.send(csv);
    });
  }); 

// app.get("/api/export", verifyToken, (req, res) => {
//   db.all("SELECT * FROM measurements ORDER BY timestamp", [], (err, rows) => {
//     if (err) {
//       console.error("Eroare la export:", err.message);
//       return res.status(500).json({ message: "Eroare la export." });
//     }

//     // Verificare: dacă nu ai date
//     if (!rows || rows.length === 0) {
//       return res.status(404).json({ message: "Nu există date de exportat." });
//     }

//     // Procesare și completare coloane
//     const enrichedRows = rows.map((row) => {
//       const date = new Date(row.timestamp);
//       const month = date.getMonth() + 1;

//       let anotimp = "primăvară";
//       if ([12, 1, 2].includes(month)) anotimp = "iarna";
//       else if ([6, 7, 8].includes(month)) anotimp = "vară";
//       else if ([9, 10, 11].includes(month)) anotimp = "toamnă";

//       return {
//         id: row.id,
//         temperature: row.temperature,
//         humidity: row.humidity,
//         timestamp: row.timestamp,
//         anotimp,
//         predictie_temp: parseFloat((row.temperature + 0.5).toFixed(1)),
//         predictie_umiditate: parseFloat((row.humidity + 1.2).toFixed(1))
//       };
//     });

//     try {
//       const fields = [
//         "id",
//         "temperature",
//         "humidity",
//         "timestamp",
//         "anotimp",
//         "predictie_temp",
//         "predictie_umiditate"
//       ];
//       const json2csvParser = new Parser({ fields });
//       const csv = json2csvParser.parse(enrichedRows);

//       res.header("Content-Type", "text/csv");
//       res.attachment("masuratori.csv");
//       return res.send(csv);
//     } catch (parseErr) {
//       console.error("Eroare la parsare CSV:", parseErr.message);
//       return res.status(500).json({ message: "Eroare la generarea CSV-ului." });
//     }
//   });
// });

  


  