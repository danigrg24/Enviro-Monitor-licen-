const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const SECRET_KEY = "enviro_secret"; // poți muta asta într-un .env

// Utilizator de test
const mockUser = {
  username: "admin",
  // Parolă: admin123
  passwordHash: bcrypt.hashSync("admin123", 10)
};

function authenticate(req, res) {
  const { username, password } = req.body;

  if (username !== mockUser.username) {
    return res.status(401).json({ message: "Utilizator inexistent" });
  }

  const isValid = bcrypt.compareSync(password, mockUser.passwordHash);
  if (!isValid) {
    return res.status(401).json({ message: "Parolă incorectă" });
  }

  const token = jwt.sign({ username }, SECRET_KEY, { expiresIn: "2h" });
  res.json({ token });
}

function verifyToken(req, res, next) {
  const authHeader = req.headers["authorization"];
  if (!authHeader) return res.sendStatus(401);

  const token = authHeader.split(" ")[1];
  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

module.exports = {
  authenticate,
  verifyToken
};
